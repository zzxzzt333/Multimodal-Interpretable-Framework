import json
import base64
import os
import re
import random
from collections import defaultdict
from openai import OpenAI
from glob import glob


ROOT_DIR = "/Users/llang/Downloads/0.5019607843137255"
IMAGE_DIR = os.path.join(ROOT_DIR, "best_results")
JSON_DIR = os.path.join(ROOT_DIR, "labels_plus")
OUTPUT_DIR = "output/batch_results"
DISCUSSION_ROUNDS = 2


client = OpenAI()

def extract_matching_key_from_filename(filename):
    match = re.search(r'([a-zA-Z]+_\d{6}_\d{6})', filename)
    if match:
        return match.group(1)
    return None

def encode_image_to_base64(image_path):
    with open(image_path, "rb") as img_file:
        return base64.b64encode(img_file.read()).decode("utf-8")

def load_attack_info(json_path):
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f)

def gpt_respond(messages):
    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=messages,
        max_tokens=800
    )
    reply = response.choices[0].message.content
    messages.append({"role": "assistant", "content": reply})
    return reply

def save_conversation(attacker_ctx, defender_ctx, expert_ctx, output_path):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    def extract_text_content(message):
        content = message.get("content")
        if isinstance(content, list):
            return "\n".join([item["text"] for item in content if item["type"] == "text"])
        elif isinstance(content, str):
            return content
        return ""

    with open(output_path, "w", encoding="utf-8") as f:
        for i in range(len(attacker_ctx)):
            if i < len(attacker_ctx):
                text = extract_text_content(attacker_ctx[i])
                if text.strip():
                    f.write(f"\n🟥 Attacker: {text}\n")
            if i < len(defender_ctx):
                text = extract_text_content(defender_ctx[i])
                if text.strip():
                    f.write(f"\n🟦 Defender: {text}\n")
        f.write("\n🟩 Expert Summary:\n" + expert_ctx[-1]["content"] + "\n")


def run_multiagent_conversation(json_path, image_path, discussion_rounds, conversation_output_path=None, question_id=0):
    attack_data = load_attack_info(json_path)
    image_base64 = encode_image_to_base64(image_path)

    system_prompt = "You are an AI agent specializing in image security. Your task is to play either an attacker or a defender and deeply analyze the motivations and intentions behind an adversarial attack."
    image_info = (
        f"The attacked region in the image is located at {attack_data['bbox']}. "
        f"The original class of the target is \"{attack_data['ori_class']}\", but after the attack, the victim model incorrectly classifies it as \"{attack_data['target_class']}\"."
    )

    attacker_ctx = [{"role": "system", "content": system_prompt}]
    defender_ctx = [{"role": "system", "content": system_prompt}]

    attacker_ctx.append({
        "role": "user",
        "content": [
            {"type": "text", "text": f"{image_info}\nAs the attacker, describe the current situation and your motivations for attacking this target."},
            {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"}}
        ]
    })
    attacker_reply = gpt_respond(attacker_ctx)

    defender_ctx.append({
        "role": "user",
        "content": [
            {"type": "text", "text": f"{image_info}\nAs the defender, analyze the attacker's true intentions based on the scenario and target location, and present your viewpoint."},
            {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"}}
        ]
    })
    defender_reply = gpt_respond(defender_ctx)

    for i in range(1, discussion_rounds):
        attacker_ctx.append({
            "role": "user",
            "content": f"The defender replied: “{defender_reply}”\n defender think attacker are just describing it in broad terms without really stating the purpose of the attack.\nAs the attacker, identify any flaws in the defender's logic and defend your intent."
        })
        attacker_reply = gpt_respond(attacker_ctx)

        defender_ctx.append({
            "role": "user",
            "content": f"The attacker replied: “{attacker_reply}”\nAs the defender, continue analyzing and interpreting the attacker’s motivations."
        })
        defender_reply = gpt_respond(defender_ctx)

    expert_ctx = [{"role": "system", "content": "You are an image security expert. Based on the visual context and target location, provide the most likely motivation behind the attack."}]
    summary_prompt = f"The following is a multi-turn discussion between the attacker and defender:\n\nAttacker: {attacker_ctx[-1]['content']}\n\nDefender: {defender_ctx[-1]['content']}\n\n"
    # expert_ctx.append({"role": "user", "content": summary_prompt})
    expert_ctx = [
        {
            "role": "system",
            # "content": "You are an image security expert. Based on the visual context and target location, provide the most likely motivation behind the attack."
            "content": (
                "You are an image security expert. Considering the visual context of the scene and the specific region targeted in the image, provide a concise explanation of the most plausible motivation behind this attack in natural language. Avoid listing points—respond with a coherent, single-paragraph analysis. "
                f"The attacked region in the image is located at {attack_data['bbox']}. "
                f"The original class of the target is \"{attack_data['ori_class']}\", "
                f"but after the attack, the victim model incorrectly classifies it as \"{attack_data['target_class']}\"."
            )
        },
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": (
                        "The following is a multi-turn discussion between the attacker and defender:\n\n"
                        f"Attacker: {attacker_ctx[-1]['content']}\n\n"
                        f"Defender: {defender_ctx[-1]['content']}\n\n"
                        "Please analyze the image below in conjunction with this conversation."
                    )
                },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:image/jpeg;base64,{image_base64}"
                    }
                }
            ]
        }
    ]
    summary_reply = gpt_respond(expert_ctx)

    if conversation_output_path:
        save_conversation(attacker_ctx, defender_ctx, expert_ctx, conversation_output_path)

    return {
        "question_id": question_id,
        "model": "GPT4.1-mini",
        "text": summary_reply,
        "image_path": image_path,
        "json_path": json_path,
        # "image_base64": image_base64,  
        # "json_content": attack_data, 
    }


def batch_process_match_by_number(image_dir, json_dir, output_path, discussion_rounds):
    samples_by_class_pair = defaultdict(list)
    image_files = glob(os.path.join(image_dir, "*.png"))
    json_files = glob(os.path.join(json_dir, "*.json"))

    json_map = {}
    for json_path in json_files:
        key = extract_matching_key_from_filename(os.path.basename(json_path))
        if key:
            json_map.setdefault(key, []).append(json_path)

    for image_path in image_files:
        image_name = os.path.basename(image_path)
        key = extract_matching_key_from_filename(image_name)
        if not key:
            continue
        matched_jsons = json_map.get(key, [])
        if not matched_jsons:
            continue

        for json_path in matched_jsons
            attack_data = load_attack_info(json_path)
            ori_class = attack_data.get("ori_class", "unknown")
            target_class = attack_data.get("target_class", "unknown")
            class_pair = (ori_class, target_class)
            samples_by_class_pair[class_pair].append((image_path, json_path))
  
    all_results = []
    question_id = 0
    for image_path, json_path in selected:
        txt_name = os.path.splitext(os.path.basename(json_path))[0] + ".txt"
        conversation_output_path = os.path.join(OUTPUT_DIR, "rounds_2", txt_name)
        os.makedirs(os.path.dirname(conversation_output_path), exist_ok=True)

        result = run_multiagent_conversation(
            json_path,
            image_path,
            discussion_rounds,
            conversation_output_path=conversation_output_path,
            question_id=question_id
        )
        all_results.append(result)
        question_id += 1

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)

# 主函数入口
if __name__ == "__main__":
    OUTPUT_JSON_PATH = "output/results_rounds.json"
    MAX_ITEMS = 50
    batch_process_match_by_number(IMAGE_DIR, JSON_DIR, OUTPUT_JSON_PATH, DISCUSSION_ROUNDS)