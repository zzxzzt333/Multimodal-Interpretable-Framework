import torch
from torch import nn
import torch.nn.functional as F
import math


def normalize_to_01(x):
    return (x - x.min()) / (x.max() - x.min() + 1e-8)


def simple_train_val_forward(model: nn.Module, gt=None, image=None, **kwargs):
    if model.training:
        assert gt is not None and image is not None
        return model(gt, image, **kwargs)
    else:
        time_ensemble = kwargs.pop('time_ensemble') if 'time_ensemble' in kwargs else False
        gt_sizes = kwargs.pop('gt_sizes') if time_ensemble else None
        pred = model.sample(image, **kwargs)
        if time_ensemble:
            preds = torch.concat(model.history, dim=1).detach().cpu()
            pred = torch.mean(preds, dim=1, keepdim=True)

            def process(i, p, gt_size):
                p = F.interpolate(p.unsqueeze(0), size=gt_size, mode='bilinear', align_corners=False)
                p = normalize_to_01(p)
                ps = F.interpolate(preds[i].unsqueeze(0), size=gt_size, mode='bilinear', align_corners=False)
                preds_round = (ps > 0).float().mean(dim=1, keepdim=True)
                p_postion = (preds_round > 0.5).float()
                p = p_postion * p
                return p

            pred = [process(index, p, gt_size) for index, (p, gt_size) in enumerate(zip(pred, gt_sizes))]
        return {
            "image": image,
            "pred": pred,
            "gt": gt if gt is not None else None,
        }


def modification_train_val_forward(model: nn.Module, gt=None, image=None, seg=None, **kwargs):
    """This is for the modification task. When diffusion model add noise, will use seg instead of gt."""
    if model.training:
        assert gt is not None and image is not None and seg is not None
        return model(gt, image, seg=seg, **kwargs)
    else:
        time_ensemble = kwargs.pop('time_ensemble') if 'time_ensemble' in kwargs else False
        gt_sizes = kwargs.pop('gt_sizes') if time_ensemble else None
        pred = model.sample(image, **kwargs).detach().cpu()
        if time_ensemble:
            """ Here is the function 3, Uncertainty based"""
            preds = torch.concat(model.history, dim=1).detach().cpu()
            pred = torch.mean(preds, dim=1, keepdim=True)

            def process(i, p, gt_size):
                p = F.interpolate(p.unsqueeze(0), size=gt_size, mode='bilinear', align_corners=False) 
                p = normalize_to_01(p)
                ps = F.interpolate(preds[i].unsqueeze(0), size=gt_size, mode='bilinear', align_corners=False)
                preds_round = (ps > 0).float().mean(dim=1, keepdim=True)
                p_postion = (preds_round > 0.5).float()
                p = p_postion * p
                return p

            pred = [process(index, p, gt_size) for index, (p, gt_size) in enumerate(zip(pred, gt_sizes))]
        return {
            "image": image,
            "pred": pred,
            "gt": gt if gt is not None else None,
        }


def modification_train_val_forward_e(model: nn.Module, gt=None, image=None, seg=None, **kwargs):
    """This is for the modification task. When diffusion model add noise, will use seg instead of gt."""
    if model.training:
        assert gt is not None and image is not None and seg is not None
        return model(gt, image, seg=seg, **kwargs)
    else:
        time_ensemble = kwargs.pop('time_ensemble') if 'time_ensemble' in kwargs else False
        gt_sizes = kwargs.pop('gt_sizes') if time_ensemble else None
        pred = model.sample(image, **kwargs).detach().cpu()
        if time_ensemble:
            """ Here is extend function 4, with batch extend."""
            preds = torch.concat(model.history, dim=1).detach().cpu()
            for i in range(2):
                model.sample(image, **kwargs)
                preds = torch.cat([preds, torch.concat(model.history, dim=1).detach().cpu()], dim=1)
            pred = torch.mean(preds, dim=1, keepdim=True)

            def process(i, p, gt_size):
                p = F.interpolate(p.unsqueeze(0), size=gt_size, mode='bilinear', align_corners=False)
                p = normalize_to_01(p)
                ps = F.interpolate(preds[i].unsqueeze(0), size=gt_size, mode='bilinear', align_corners=False)
                preds_round = (ps > 0).float().mean(dim=1, keepdim=True)
                p_postion = (preds_round > 0.5).float()
                p = p_postion * p
                return p

            pred = [process(index, p, gt_size) for index, (p, gt_size) in enumerate(zip(pred, gt_sizes))]
        return {
            "image": image,
            "pred": pred,
            "gt": gt if gt is not None else None,
        }




def log(t, eps = 1e-20):
    return torch.log(t.clamp(min = eps))

def alpha_cosine_log_snr(t, s=0.008):
    return log((torch.cos((t + s) / (1 + s) * math.pi * 0.5) ** -2) - 1, eps = 1e-5)

def compute_snr_weight(timesteps):
    snr = alpha_cosine_log_snr(timesteps /len(timesteps))
    snr_weights = snr - snr[0] * 2
    return snr_weights / snr_weights.sum()

def dempster_combine_batched(bpa1, bpa2):
    pred1, non_pred1 = bpa1[..., 0], bpa1[..., 1]
    pred2, non_pred2 = bpa2[..., 0], bpa2[..., 1]

    pred_combined = (pred1 * pred2) + (pred1 * non_pred2) + (non_pred1 * pred2)
    non_pred_combined = (non_pred1 * non_pred2)

    return torch.stack([pred_combined, non_pred_combined], dim=-1)


def dsmt_fusion(preds, time_step_based=True):
    batch_size, num_samples, H, W = preds.shape

    if time_step_based:
        time_weights = compute_snr_weight(torch.arange(num_samples, device=preds.device))
        bpa = torch.zeros(batch_size, num_samples, H, W, 2, device=preds.device)
        for t in range(num_samples):
            weighted_preds = preds[:, t, :, :] * time_weights[t]
            bpa[:, t, :, :, 0] = weighted_preds  # pred
            bpa[:, t, :, :, 1] = (1 - weighted_preds)  # non-pred

        combined_bpa = bpa[:, 0, :, :, :]
        for t in range(1, num_samples):
            combined_bpa = dempster_combine_batched(combined_bpa, bpa[:, t, :, :, :])

        fused_pred = combined_bpa[..., 0]

    else:
        bpa = torch.zeros(batch_size, num_samples, H, W, 2, device=preds.device)

        for t in range(num_samples):
            bpa[:, t, :, :, 0] = preds[:, t, :, :]  # pred
            bpa[:, t, :, :, 1] = 1 - preds[:, t, :, :]  # non-pred

        combined_bpa = bpa[:, 0, :, :, :]

        for t in range(1, num_samples):
            combined_bpa = dempster_combine_batched(combined_bpa, bpa[:, t, :, :, :])


        fused_pred = combined_bpa[..., 0] 

    return fused_pred

def modification_train_val_forward_e_dsmt(model: nn.Module, gt=None, image=None, seg=None, **kwargs):
    """This is for the modification task. When diffusion model add noise, will use seg instead of gt."""
    if model.training:
        assert gt is not None and image is not None and seg is not None
        return model(gt, image, seg=seg, **kwargs)
    else:
        time_ensemble = kwargs.pop('time_ensemble') if 'time_ensemble' in kwargs else False
        gt_sizes = kwargs.pop('gt_sizes') if time_ensemble else None
        
        if time_ensemble:
            """Here is extend function 4, with batch extend."""
            fused_preds = [] 

            for _ in range(3): 
                model.sample(image, **kwargs)
                preds = torch.concat(model.history, dim=1).detach().cpu() 
                
                fused_pred = dsmt_fusion(preds).unsqueeze(1)  
                fused_preds.append(fused_pred)
            
            pred = torch.mean(torch.stack(fused_preds, dim=0), dim=0)

            def process(i, p, gt_size):
                p = F.interpolate(p.unsqueeze(0), size=gt_size, mode='bilinear', align_corners=False)
                p = normalize_to_01(p)
                ps = F.interpolate(preds[i].unsqueeze(0), size=gt_size, mode='bilinear', align_corners=False)
                preds_round = (ps > 0).float().mean(dim=1, keepdim=True)
                p_postion = (preds_round > 0.5).float()
                p = p_postion * p
                return p

            pred = [process(index, p, gt_size) for index, (p, gt_size) in enumerate(zip(pred, gt_sizes))]

        return {
            "image": image,
            "pred": pred,
            "gt": gt if gt is not None else None,
        }
