import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader
import torchvision
from albumentations.core.transforms_interface import ImageOnlyTransform
import os
import json
import numpy as np
from PIL import Image, ImageDraw
from torch.utils.data import Dataset
from torchvision import transforms
import glob
from albumentations.core.transforms_interface import ImageOnlyTransform
import albumentations as A
from albumentations.pytorch import ToTensorV2
from torchvision import models
from tqdm import tqdm
import timm
import random
import torch.nn.functional as F
import os
from PIL import Image
import numpy as np
from torch.utils.data import Dataset
from torch.cuda.amp import autocast, GradScaler

class DenoisingNet(nn.Module):
    def __init__(self, pretrained=True):
        super().__init__()
        resnet = timm.create_model('resnet50d', pretrained=pretrained, features_only=True)

        self.enc0 = resnet.feature_info[0]['num_chs']
        self.enc1 = resnet.feature_info[1]['num_chs']
        self.enc2 = resnet.feature_info[2]['num_chs']
        self.enc3 = resnet.feature_info[3]['num_chs']
        self.enc4 = resnet.feature_info[4]['num_chs']

        self.encoder = resnet

        self.up4 = self._up_block(self.enc4, self.enc3)
        self.up3 = self._up_block(self.enc3 + self.enc3, self.enc2)
        self.up2 = self._up_block(self.enc2 + self.enc2, self.enc1)
        self.up1 = self._up_block(self.enc1 + self.enc1, self.enc0)
        self.up0 = self._up_block(self.enc0 + self.enc0, 64)

        self.final = nn.Conv2d(64, 3, kernel_size=1)

    def _up_block(self, in_channels, out_channels):
        return nn.Sequential(
            nn.ConvTranspose2d(in_channels, out_channels, kernel_size=2, stride=2),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        feats = self.encoder(x)
        e0, e1, e2, e3, e4 = feats

        d4 = self.up4(e4)
        d3 = self.up3(torch.cat([d4, e3], dim=1))
        d2 = self.up2(torch.cat([d3, e2], dim=1))
        d1 = self.up1(torch.cat([d2, e1], dim=1))
        d0 = self.up0(torch.cat([d1, e0], dim=1))

        out = self.final(d0)
        return out
    
class AdvSearchCleanDataset(Dataset):
    def __init__(self, clean_root, adv_root, transform=None, mode=None):
        self.clean_root = clean_root
        self.adv_root = adv_root
        self.transform = transform
        self.mode = mode
        self.classes = sorted(os.listdir(clean_root))
        self.class_to_idx = {cls_name: idx for idx, cls_name in enumerate(self.classes)}
        self.clean_name_map = {}
        for cls_name in self.classes:
            cls_dir = os.path.join(clean_root, cls_name)
            for fname in os.listdir(cls_dir):
                if fname.lower().endswith(('.png', '.jpg', '.jpeg')):
                    name_no_ext = os.path.splitext(fname)[0]
                    full_path = os.path.join(cls_dir, fname)
                    label = self.class_to_idx[cls_name]
                    self.clean_name_map[name_no_ext] = (full_path, label)

        self.samples = []
        same_label_count = 0  

        for root, _, files in os.walk(adv_root):
            for adv_fname in files:
                if not adv_fname.lower().endswith(('.png', '.jpg', '.jpeg')):
                    continue

                adv_path = os.path.join(root, adv_fname)
                adv_cls_name = os.path.basename(os.path.dirname(adv_path))
                adv_label = self.class_to_idx.get(adv_cls_name, -1)

                adv_name_no_ext = os.path.splitext(adv_fname)[0]
                if adv_name_no_ext in self.clean_name_map:
                    clean_path, clean_label = self.clean_name_map[adv_name_no_ext]
                else:
                    matched = [v for k, v in self.clean_name_map.items() if k in adv_name_no_ext]
                    if len(matched) == 0:
                        print(f"[WARN] No clean match for: {adv_fname}")
                        continue
                    elif len(matched) > 1:
                        raise ValueError(f"[ERROR] Multiple matches for '{adv_fname}': {[k for k in self.clean_name_map if k in adv_name_no_ext]}")
                    clean_path, clean_label = matched[0]

                if clean_label == adv_label:
                    print(f"[NOTE] Same label for clean and adv: {adv_fname} | Label: {clean_label}")
                    same_label_count += 1

                self.samples.append((clean_path, adv_path, clean_label, adv_label))

        print(f"✅ Dataset constructed: {len(self.samples)} pairs found.")
        print(f"⚠️  Pairs with same clean and adv labels: {same_label_count}")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        clean_path, adv_path, clean_label, adv_label = self.samples[idx]
        clean_img = Image.open(clean_path).convert('RGB')
        adv_img = Image.open(adv_path).convert('RGB')

        if self.transform:
            transformed = self.transform(image=np.array(clean_img))
            clean_img = transformed["image"]
            replay = transformed["replay"]
            adv_img = A.ReplayCompose.replay(replay, image=np.array(adv_img))["image"]


        return clean_img, adv_img, clean_label

transform = A.ReplayCompose([
    A.LongestMaxSize(max_size=224),
    A.PadIfNeeded(min_height=224, min_width=224, border_mode=0, value=(0, 0, 0)),
    A.HorizontalFlip(p=0.5),
    A.Rotate(limit=10, border_mode=0, value=(0, 0, 0), p=0.3),
    A.ShiftScaleRotate(shift_limit=0.05, scale_limit=0.05, rotate_limit=0, border_mode=0, value=(0, 0, 0), p=0.3),
    A.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
    ToTensorV2()
])

transform_val = A.ReplayCompose([
    A.LongestMaxSize(max_size=224), 
    A.PadIfNeeded(min_height=224, min_width=224, 
                  border_mode=0, value=(0, 0, 0)), 

    A.Normalize(mean=(0.485, 0.456, 0.406), 
                std=(0.229, 0.224, 0.225)), 
    ToTensorV2()
])


clean_train_dir = "int_data/ori_clean_all"
att_train_dir = "int_data/image/train"

clean_val_dir = "int_data/ori_clean_val"
att_val_dir = "int_data/image/val"


train_dataset = AdvSearchCleanDataset(clean_train_dir, att_train_dir, transform=transform, mode="train")
val_dataset = AdvSearchCleanDataset(clean_val_dir, att_val_dir, transform=transform_val, mode="val")

train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=16, shuffle=False)


classes =  ('person', 'rider', 'car', 'truck', 'bus', 'train', 'motorcycle', 'bicycle')
    
num_classes = len(classes)  

denoiser = DenoisingNet(pretrained=True).cuda()
classifier = timm.create_model('resnet50d', pretrained=True, num_classes=len(classes)).cuda()

params = list(denoiser.parameters()) + list(classifier.parameters())
optimizer_joint = torch.optim.AdamW(params, lr=1e-4)

criterion_rec = nn.MSELoss()
criterion_cls = nn.CrossEntropyLoss()

best_val_acc = 0
scaler = GradScaler()

scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer_joint, T_max=50)

best_val_acc = 0
patience = 15
stop_counter = 0

warmup_epochs = 5  

for epoch in range(100):
    denoiser.train()
    classifier.train()
    total_loss = 0
    correct = 0
    total = 0

    if epoch < warmup_epochs:
        for p in denoiser.parameters():
            p.requires_grad = False
        for p in classifier.parameters():
            p.requires_grad = True
    else:
        for p in denoiser.parameters():
            p.requires_grad = True
        for p in classifier.parameters():
            p.requires_grad = True

    for clean_img, adv_img, label in tqdm(train_loader, desc=f"Joint Epoch {epoch+1}"):
        label = label.long().cuda()
        clean_img = clean_img.cuda()
        adv_img = adv_img.cuda()

        optimizer_joint.zero_grad()

        with autocast(): 
            denoised_img = denoiser(adv_img)
            logits = classifier(denoised_img)
            clean_logits = classifier(clean_img)

            loss_rec = criterion_rec(denoised_img, clean_img)
            loss_cls = criterion_cls(logits, label)
            loss_cls_clean = criterion_cls(clean_logits, label)
            loss_kl = F.kl_div(
                F.log_softmax(logits, dim=1),
                F.softmax(clean_logits.detach(), dim=1),
                reduction='batchmean'
            )
 
            loss = loss_cls + loss_kl + 0.5 * loss_rec + 0.5*loss_cls_clean

        scaler.scale(loss).backward()

        scaler.unscale_(optimizer_joint)
        torch.nn.utils.clip_grad_norm_(params, max_norm=1.0)

        scaler.step(optimizer_joint)
        scaler.update()

        total_loss += loss.item()
        pred = logits.argmax(dim=1)
        correct += pred.eq(label).sum().item()
        total += label.size(0)

    scheduler.step()  

    acc = 100. * correct / total
    print(f"[Joint Epoch {epoch+1}] Loss: {total_loss:.4f}, Acc: {acc:.2f}%")

    denoiser.eval()
    classifier.eval()
    val_correct = 0
    val_total = 0

    with torch.no_grad():
        for clean_img, adv_img, label in val_loader:
            label = label.long().cuda()
            adv_img = adv_img.cuda()

            denoised_img = denoiser(adv_img)
            logits = classifier(denoised_img)
            pred = logits.argmax(dim=1)
            val_correct += pred.eq(label).sum().item()
            val_total += label.size(0)

    val_acc = 100. * val_correct / val_total
    print(f"[Joint Epoch {epoch+1}] ✅ Val Acc: {val_acc:.2f}%")

    # Early stopping
    if val_acc > best_val_acc:
        best_val_acc = val_acc
        stop_counter = 0
        torch.save({
            'denoiser': denoiser.state_dict(),
            'classifier': classifier.state_dict()
        }, "best_joint_model_unnet.pth")
        print(f"📌 New best model saved at epoch {epoch+1} with acc {val_acc:.2f}%")
    else:
        stop_counter += 1

    if stop_counter >= patience:
        print("🔁 Early stopping triggered.")
        break